<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Thank you for registering your new account!</h1>
			</div>
			<p>You have successfully register. Please check your email inbox to confirm your email address.</p>
		</div>
	</div><!-- .row -->
</div><!-- .container -->